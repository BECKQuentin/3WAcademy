
<?php

$template = 'admin';

include 'layout.phtml';



?>